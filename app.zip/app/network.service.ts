import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of,throwError } from 'rxjs';
import { Http, HttpResponse } from '@capacitor-community/http';

@Injectable({
  providedIn: 'root'
})
export class NetworkService {

  constructor(private http: HttpClient) { }

  post() {
	const url = "http://localhost:3001/test";
	// const url = "http://k8s-developm-ingressa-1c98111f81-862727769.ap-south-1.elb.amazonaws.com/jobseeker/otp";
    const reqObj = {
		"loginType": "MOBILE",
		"username": "+919876543210"
	};
    const options = {
      url: url,
      data: reqObj,
      headers: { 'Content-Type': 'application/json' }
    };
    Http.request({ ...options, method: 'POST' })
      .then(async response => {
		console.info("response",response);
      })
      .catch(e => {
        console.info("error",e);
        
      })
  }

  httpPost(_url:any,reqObj:any):Observable<any> {
		const _httpOptions = {
			"Content-Type":"Application/json",
			"Accept": "application/json"
		  };
	
		// //fake post url
		// const url = "https://reqres.in/api/users";
		// reqObj = {
	  //       name: "paul rudd",
	  //       movies: ["", "Role Models"]
	  //   };

		
		// const url = "http://localhost:3001/test";
		// const url = "http://10.0.2.2:3001/test"; //emulator
		// const url = "http://192.168.1.34:3001/test"; //device with same network
		
		// //jobseeker_otp API
		// const url = "http://k8s-developm-ingressa-1c98111f81-862727769.ap-south-1.elb.amazonaws.com/jobseeker/otp";
		// reqObj = {
	    //     "loginType": "MOBILE",
	    //     "username": "+919876543210"
	    // };
		
		//login with mobile_number API
		const url = "http://k8s-developm-ingressa-1c98111f81-862727769.ap-south-1.elb.amazonaws.com/oauth2/token";
		reqObj = {
	        "username": "+919876543210",
			"grant_type": "grant_otp",
			"otp":"728188",
			"username_attr_type":"mobile_number",
			
	    };
		
		
	// // const formBody = Object.keys(reqObj).map(key => encodeURIComponent(key) + '=' + encodeURIComponent(reqObj[key])).join('&');

	// 	//login with email_id API
	// 	const url = "http://k8s-developm-ingressa-1c98111f81-862727769.ap-south-1.elb.amazonaws.com/oauth2/token";
	// 	reqObj = {
	//         "grant_type": "grant_otp",
	//         "username": "mallampati.sandeep@gmail.com",
	// 		"otp":"728188",
	// 		"username_attr_type":"email_id"
	//     };
		
		const formBody = Object.keys(reqObj).map(key => encodeURIComponent(key) + '=' + encodeURIComponent(reqObj[key])).join('&');
		
		const headers = new HttpHeaders({
			'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
			"Authorization":"Basic ZGVtby1jbGllbnQ6ZGVtby1zZWNyZXQ="
		  });

		  const options = { headers: headers };
		console.info("before api call",url,formBody);
		return this.http.post(url,formBody, options);
	}
}
