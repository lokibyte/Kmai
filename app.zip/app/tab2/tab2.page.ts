import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { finalize, Subscription, takeWhile, tap, timer } from 'rxjs';
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit, OnDestroy{
  duration: number = 30;
  videoBlobs: Array<Array<Blob>> = [];
  idx: number=1;
  secondPassed: number = 0;
  timerSubs: Subscription;
  displayTime: string = '00:00'
  min = 0;
  sec = 0;

  buttonState = {
    isRecording: false,
    preview: false,
    showingPreview: false,
    showRetake: false
  }

  @ViewChild('camera') camerVideoElementRef: ElementRef;
  videoElement: HTMLVideoElement;

  downloadUrl: string;
  stream: MediaStream;
  recordedData: Array<Blob> = [];
  mediaRecorder: MediaRecorder;

  ngOnInit(): void {
    this.initVideo();
  }
  constructor() {}
  startRecording() {
    this.recordedData = [];
    let options: any = {
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 2500000,
      mimeType: 'video/webm',

    };

    try {
      this.mediaRecorder = new MediaRecorder(this.stream, options);
    } catch (err) {
      console.log(err);
    }

    this.mediaRecorder.start(); // collect 100ms of data
    this.buttonState.isRecording = !this.buttonState.isRecording;
    this.onDataAvailableEvent();
    this.onStopRecordingEvent();
    this.startRecodingDuration();
  }
  startRecodingDuration() {
    this.timerSubs = timer(0, 1000)
      .pipe(
        finalize(() => {
          this.stopRecording();
        }),
        takeWhile(() => this.secondPassed <= this.duration),
        tap(() => {
          const minStr = this.min.toString();
          const secStr = this.sec.toString();
          this.displayTime = minStr.padStart(2, '0') + ':' + secStr.padStart(2, '0');
          this.secondPassed++;
          --this.sec;
          if (this.sec == -1) {
            --this.min;
            this.sec = 59;
          }

        })).subscribe();

  }
  onStopClick(): void {
    this.timerSubs.unsubscribe(); //this will call the finalize define within the timer
  }

  stopRecording() {
    this.mediaRecorder.stop();
    this.buttonState.isRecording = !this.buttonState.isRecording;
    this.buttonState.preview = !this.buttonState.preview;
    this.buttonState.showRetake = !this.buttonState.showRetake;
    console.log('Recorded Blobs: ', this.recordedData);
    // this.timerSubs.unsubscribe();
  }

  onDataAvailableEvent() {
    try {
      this.mediaRecorder.ondataavailable = (event: BlobEvent) => {
        if (event.data && event.data.size > 0) {
          this.recordedData.push(event.data);
        }
      };
    } catch (error) {
      console.log(error);
    }
  }

  onStopRecordingEvent() {
    try {
      this.mediaRecorder.onstop = (event: Event) => {
        this.videoBlobs[this.idx] = this.recordedData;
        const videoBuffer = new Blob(this.recordedData, {
          type: 'video/webm'
        });
        this.downloadUrl = window.URL.createObjectURL(videoBuffer); // you can download with <a> tag
        this.stream.getTracks().forEach(track => track.stop());
        console.log('Map :: ', this.videoBlobs);
        console.log('Download Url :: ', this.downloadUrl);
      };
    } catch (error) {
      console.log(error);
    }
  }

  showPreview(): void {
    console.log("Preview Url:", this.downloadUrl);
    this.buttonState.showingPreview = true;
    
    this.videoElement.srcObject = null;
    this.videoElement.src = this.downloadUrl;
    this.videoElement.muted = false;
    this.videoElement.controls = true;
    
  }

  ngOnDestroy(): void {
    // this.timerSubs.unsubscribe();
  }

  initVideo() {
    this.buttonState = {
      isRecording: false,
      preview: false,
      showingPreview: false,
      showRetake: false
    }
    this.secondPassed = 0;
    this.displayTime = '00:00';
    this.min = Math.floor(this.duration / 60);
    this.sec = this.duration % 60;
    if (this.videoElement)
      this.videoElement.controls = false;
    navigator.mediaDevices
      .getUserMedia({
        audio: {
          echoCancellation: true
        },
        video: {
          width: 360
        }
      })
      .then(stream => {
        this.videoElement = this.camerVideoElementRef.nativeElement;
        this.stream = stream;
        this.videoElement.muted = true;
        this.videoElement.srcObject = this.stream;
      });
  }

  stopRecOrPausePlay() {
    if (this.buttonState.isRecording) {
      this.timerSubs.unsubscribe(); //this will call the finalize define within the timer
    } else if (this.buttonState.showingPreview) {
      this.videoElement.pause();
    }
  }
}
