import { Component, OnInit } from '@angular/core';
import { CameraPreview,CameraPreviewOptions } from '@capgo/camera-preview';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  urleducationVideo:any;
  educationVideo:any;
  constructor() {}
  
  ngOnInit() {
    this.educationVideo = document.getElementById('education-recorded') as HTMLVideoElement;
  }
  previewVideo(){
    const cameraPreviewOptions: CameraPreviewOptions = {
      position: 'front',
      height: 200,
      width: 300,
      y:300,
      parent: "cameraPreview"
    };
    CameraPreview.start(cameraPreviewOptions);
    // CameraPreview.start({ parent: "cameraPreview"});
  }

  recordVideo(){
    const cameraPreviewOptions: CameraPreviewOptions = {
      position: 'front',
      height: 200,
      width: 300,
      y:300,
      parent: "cameraPreview"
    };
    CameraPreview.startRecordVideo(cameraPreviewOptions);
  }
  async stopVideo(){
    let path = await CameraPreview.stopRecordVideo();
    let _path = await CameraPreview.stop();

    // this.urleducationVideo = path?.videoFilePath;
    console.info("_path",_path);
    console.info("path",path);
    let ln = path?.videoFilePath.split("/")
    let filename = "file:///android_asset/data/data/data/"+ln[ln.length-1];
    console.info("this.urleducationVideo",this.urleducationVideo);
    this.urleducationVideo = filename;
    await this.educationVideo.load();
    
    setTimeout(async ()=>{
      await this.educationVideo.play();
    },2000)
  }
}
