import { Route } from "@angular/router";
import { CaptureVideoComponent } from "./capture-video/capture-video.component";
import { ThankYouComponent } from "./thank-you/thank-you.component";
import { VerifyEmailComponent } from "./verify-email/verify-email.component";

export const videoResumeRoutes: Route[] = [
    { path: '', pathMatch: 'full', redirectTo: 'verify-email'},
    { path: 'verify-email/:accountUid/:candidateUid', component: VerifyEmailComponent},
    {
        path: 'record-video-resume/:accountUid/:candidateUid',
        component: CaptureVideoComponent,
    },
    {
        path:'thankyou',
        component:ThankYouComponent
      },
]
