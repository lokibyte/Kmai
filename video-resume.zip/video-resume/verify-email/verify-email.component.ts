import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from 'app/shared/app-constants';
import { VerifyVideoResumeLink } from 'app/shared/model';
import { SnackBarService } from 'app/shared/snack-bar/snack-bar.service';
import { VideoResumeService } from '../video-resume.service';

@Component({
  selector: 'app-verify-email',
  templateUrl: './verify-email.component.html',
  styleUrls: ['./verify-email.component.scss']
})
export class VerifyEmailComponent implements OnInit {

  payload = {} as VerifyVideoResumeLink;

  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private videoResumeService: VideoResumeService,
    private snackBarService: SnackBarService
  ) { }

  ngOnInit(): void {
    this.activateRoute.paramMap.subscribe(params => {
      this.payload.accountUid = params.get('accountUid');
      this.payload.candidateUid = params.get('candidateUid');
    });
  }

  onValidate() {
    this.videoResumeService.verifyLink(this.payload).subscribe(resp => {
      if (resp.success) {
        this.router.navigate(['../../../record-video-resume', this.payload.accountUid, this.payload.candidateUid], {relativeTo: this.activateRoute, skipLocationChange: true});
      } else {
        this.snackBarService.showSnackBar(appConstants.ERROR, resp.messageCodes[0]);
      }
    })
    
  }
}
