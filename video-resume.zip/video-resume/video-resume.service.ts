import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiConfig } from 'app/shared/api-url.config';
import { Response, VerifyVideoResumeLink } from 'app/shared/model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VideoResumeService {

  constructor(
    private http: HttpClient
  ) { }

  verifyLink(payload: VerifyVideoResumeLink): Observable<Response<boolean>> {
    return this.http.post<Response<boolean>>(apiConfig.preLogin.verifyVideoResumeLink, payload);
  }

  uploadVideoResume(formData: FormData): Observable<Response<boolean>> {
    return this.http.post<Response<boolean>>(apiConfig.preLogin.uploadVideoResume, formData);
  }
}
