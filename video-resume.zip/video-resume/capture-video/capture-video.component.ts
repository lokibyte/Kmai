import { Component, OnInit, ViewChild } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from 'app/shared/app-constants';
import { SnackBarService } from 'app/shared/snack-bar/snack-bar.service';
import { VideoRecorderComponent } from '../video-recorder/video-recorder.component';
import { VideoResumeService } from '../video-resume.service';

@Component({
  selector: 'app-capture-video',
  templateUrl: './capture-video.component.html',
  styleUrls: ['./capture-video.component.scss']
})
export class CaptureVideoComponent implements OnInit {

  @ViewChild("submit") matButton: MatButton;
  @ViewChild("stepper") stepper: MatStepper;

  videoBlobs: Array<Array<Blob>> = [];

  accountUid: string = '';
  candidateUid: string = '';
  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private snackbarService: SnackBarService,
    private videoResumeService: VideoResumeService
  ) { }

  ngOnInit(): void {
    this.activateRoute.paramMap.subscribe(params => {
      this.accountUid = params.get('accountUid');
      this.candidateUid = params.get('candidateUid');
    });
  }

  onNext(idx: number, recorderComponet: VideoRecorderComponent): void {
    if (idx == 3 || this.videoBlobs[idx]) {
      recorderComponet.stopRecOrPausePlay();
      this.stepper.next();
    } else {
      this.snackbarService.showSnackBar(appConstants.ERROR, 'Please complete this section first.', false);
    }
  }

  onPrev(recorderComponet: VideoRecorderComponent): void {
    recorderComponet.stopRecOrPausePlay();
    this.stepper.previous();

  }

  onSubmit(recorderComponent: VideoRecorderComponent): void {
    recorderComponent.stopRecOrPausePlay();
    this.matButton.disabled = true;
    const formData = new FormData();
    formData.append("personalDetails", new File(this.videoBlobs[0], "personal_details.webm"));
    formData.append("eduExp", new File(this.videoBlobs[1], "edu_exp.webm"));
    formData.append("skillSet", new File(this.videoBlobs[2], "skill_set.webm"));

    if (this.videoBlobs[3]) {
      formData.append("additionalInfo", new File(this.videoBlobs[3], "additional_info.webm"));
    }

    formData.append("accountUid", this.accountUid);
    formData.append("candidateUid", this.candidateUid);
    this.videoResumeService.uploadVideoResume(formData).subscribe((data) => {
      if (data.success) {
        this.snackbarService.showSnackBar(appConstants.SUCCESS, 'Video resume uploaded successfully');
        this.router.navigate(['video-resume/thankyou']);
      } else {
        this.snackbarService.showSnackBar(appConstants.ERROR, data.messages[0], true);
        this.matButton.disabled = false;
      }
    });
  }

  preview(recorderComponet: VideoRecorderComponent): void {
    recorderComponet.stopRecOrPausePlay();
    this.stepper.selectedIndex = 1;
  }
}
