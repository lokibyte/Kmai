import { Component, Input, OnInit } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';

@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.scss']
})
export class InstructionsComponent implements OnInit {

  @Input() stepper: MatStepper
  @Input() videoBlobs: Array<Array<Blob>>;

  btnLabel: string = "Start";
  oldSize: number = 0;

  constructor() { }

  ngOnInit(): void {

  }

  ngDoCheck() {
    if (this.videoBlobs.length != this.oldSize) {
      this.oldSize = this.videoBlobs.length;
      console.log('btn label changes');
      this.btnLabel = this.videoBlobs?.length > 0 ? 'Continue' : 'Start';
    }
  }

}
