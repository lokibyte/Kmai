import { TestBed } from '@angular/core/testing';

import { VideoResumeService } from './video-resume.service';

describe('VideoResumeService', () => {
  let service: VideoResumeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VideoResumeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
