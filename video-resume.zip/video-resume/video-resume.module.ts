import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CaptureVideoComponent } from './capture-video/capture-video.component';
import { VerifyEmailComponent } from './verify-email/verify-email.component';
import { RouterModule } from '@angular/router';
import { videoResumeRoutes } from './video-resume.routing';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { InstructionsComponent } from './instructions/instructions.component';
import { MatStepperModule } from '@angular/material/stepper';
import { VideoRecorderComponent } from './video-recorder/video-recorder.component';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { ThankYouComponent } from './thank-you/thank-you.component';



@NgModule({
  declarations: [
    CaptureVideoComponent,
    VerifyEmailComponent,
    InstructionsComponent,
    VideoRecorderComponent,
    ThankYouComponent,

  ],
  imports: [
    CommonModule,
    MatDividerModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatStepperModule,
    MatIconModule,
    FormsModule,
    SharedModule,
    RouterModule.forChild(videoResumeRoutes)
  ]
})
export class VideoResumeModule { }
