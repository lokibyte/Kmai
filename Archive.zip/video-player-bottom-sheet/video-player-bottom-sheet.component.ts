import { Component, Inject, OnInit } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';

@Component({
  selector: 'app-video-player-bottom-sheet',
  templateUrl: './video-player-bottom-sheet.component.html',
  styleUrls: ['./video-player-bottom-sheet.component.scss']
})
export class VideoPlayerBottomSheetComponent implements OnInit {

  constructor(
    private bottomSheetRef: MatBottomSheetRef<VideoPlayerBottomSheetComponent>,
    // @Inject(MAT_DIALOG_DATA) public data: any,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: any
  ) { }

  ngOnInit(): void {
    console.log('data player', this.data);
  }

  onClose() {
    this.bottomSheetRef.dismiss();
  }

 
}
