import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VideoPlayerBottomSheetComponent } from './video-player-bottom-sheet.component';

describe('VideoPlayerBottomSheetComponent', () => {
  let component: VideoPlayerBottomSheetComponent;
  let fixture: ComponentFixture<VideoPlayerBottomSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VideoPlayerBottomSheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VideoPlayerBottomSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
